require_relative "code"

class Mastermind
  attr_reader :secret_code


  def initialize(length)
    @secret_code = Code.random(length) 
  end
  
  def print_matches(guess)
    puts "exact matches: " + self.secret_code.num_exact_matches(guess).to_s
    puts "near matches: " + self.secret_code.num_near_matches(guess).to_s
  end

  def ask_user_for_guess
    puts "Enter a code"
    input = gets.chomp
    guess = Code.from_string(input)
    self.print_matches(guess)
    self.secret_code == guess
  end
end
