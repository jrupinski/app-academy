require "byebug"

def no_valid_url?(links)
    valid_url = [".com", ".net", ".io",".org"]
    
    links.none? do |link|
        # debugger
        valid_url.any? do |url|
            link_end = link[-url.length..-1]
            link_end == url
        end
    end
end

def any_passing_students?(students)
    students.any? { |student| student[:grades].sum / student[:grades].count > 75}
end