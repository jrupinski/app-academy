# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
require "byebug"

def largest_prime_factor(number)
    (1..number).reverse_each do |factor|
        # debugger
        if number % factor == 0 && is_prime?(factor)
            return factor
        end 
    end
end

def is_prime?(number)
    (2...number).each do |factor|
        return false if number % factor == 0
    end

    true
end

def unique_chars?(string)
    char_count = Hash.new(0)
    string.downcase.each_char { |char| char_count[char] += 1 }
    char_count.none? { |k, v| v > 1 }
end

def dupe_indices(array)
    dupes = Hash.new([])
    
    (0...array.length).each do |ele_idx|
        ele = array[ele_idx]

        if !dupes.has_key?(ele)
            dupes[ele] += [ele_idx]
            (ele_idx + 1...array.length).each do |dupl_idx|
                dupl_check = array[dupl_idx]
                # debugger
                dupes[ele] += [dupl_idx] if ele == dupl_check
            end
        end
    end

    dupes.select { |k, v| v.length > 1}
end

def ana_array(array1, array2)
    array1 = sort_array(array1)
    array2 = sort_array(array2)

    array1 == array2
end

def sort_array(array)
    sorted = false
    while !sorted
        sorted = true
        
        (0...array.length - 1).each do |idx|
            if array[idx] > array[idx+1]
                array[idx], array[idx+1] = array[idx+1], array[idx]
                sorted = false
            end
        end
    end

    return array
end

print sort_array([6,5,4,3,2,6,1,2])
