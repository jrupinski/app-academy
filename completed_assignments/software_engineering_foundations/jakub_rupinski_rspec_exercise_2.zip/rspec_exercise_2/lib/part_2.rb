def palindrome?(string)
    reversed_string = ""
    word = string.split("")
    word.reverse_each { |char| reversed_string += char }
    
    string.eql?(reversed_string)
end

def substrings(string)
    substrings = []
    string.each_char.with_index do |char, idx|
        i = idx
        while i < string.length
            substrings << string[idx..i]
            i += 1
        end
    end

    substrings
end

def palindrome_substrings(string)
    pal_substrings = []

    substrings(string).each do |substring|
        if palindrome?(substring) && substring.length > 1
            pal_substrings << substring
        end
    end

    pal_substrings
end
