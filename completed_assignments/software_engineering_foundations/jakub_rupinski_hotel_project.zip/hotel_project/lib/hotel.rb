require_relative "room"

class Hotel
  def initialize(name, rooms_hash)
    @name = name
    @rooms = {}
    rooms_hash.each { |name, capacity| @rooms[name] = Room.new(capacity)  }
  end

  def name
    capitalized = @name.split(" ")
    capitalized.each { |word| word.capitalize! }
    capitalized.join(" ")
  end

  def rooms
    @rooms
  end

  def room_exists?(room)
    @rooms.include?(room)
  end

  def check_in(person, room_name)
    if !room_exists?(room_name)
      puts "sorry, room does not exits"
      return
    end

    if @rooms[room_name].add_occupant(person) == true
      puts "check in successful"
    else
      puts "sorry, room is full"
    end
  end

  def has_vacancy?
    @rooms.any? { |room, capacity| !capacity.full? }
  end

  def list_rooms
    @rooms.each { |room, capacity| puts "#{room} : #{capacity.available_space}" }
  end
end
